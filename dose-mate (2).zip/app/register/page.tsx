"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { InputOTP, InputOTPGroup, InputOTPSlot } from "@/components/ui/input-otp"
import { ArrowLeft, Smartphone, MessageSquare, UserPlus } from "lucide-react"
import Link from "next/link"

export default function RegisterPage() {
  const [step, setStep] = useState<"details" | "mobile" | "otp">("details")
  const [formData, setFormData] = useState({
    firstName: "",
    lastName: "",
    role: "",
    mobileNumber: "",
  })
  const [otp, setOtp] = useState("")
  const [isLoading, setIsLoading] = useState(false)

  const handleDetailsNext = () => {
    if (!formData.firstName || !formData.lastName || !formData.role) return
    setStep("mobile")
  }

  const handleSendOTP = async () => {
    if (!formData.mobileNumber || formData.mobileNumber.length < 10) return
    setIsLoading(true)
    // Simulate OTP sending
    setTimeout(() => {
      setIsLoading(false)
      setStep("otp")
    }, 1500)
  }

  const handleVerifyOTP = async () => {
    if (otp.length !== 6) return
    setIsLoading(true)
    // Simulate account creation
    setTimeout(() => {
      setIsLoading(false)
      console.log("Account created successfully")
    }, 1500)
  }

  const handleResendOTP = () => {
    setOtp("")
    handleSendOTP()
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-background to-muted flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        <div className="flex items-center justify-center mb-8">
          <Link
            href="/"
            className="flex items-center gap-2 text-muted-foreground hover:text-foreground transition-colors"
          >
            <ArrowLeft className="w-4 h-4" />
            Back to Home
          </Link>
        </div>

        <Card className="border-2">
          <CardHeader className="text-center">
            <div className="w-12 h-12 bg-primary rounded-lg flex items-center justify-center mx-auto mb-4">
              {step === "details" ? (
                <UserPlus className="w-6 h-6 text-primary-foreground" />
              ) : step === "mobile" ? (
                <Smartphone className="w-6 h-6 text-primary-foreground" />
              ) : (
                <MessageSquare className="w-6 h-6 text-primary-foreground" />
              )}
            </div>
            <CardTitle className="text-2xl">
              {step === "details" ? "Create Account" : step === "mobile" ? "Mobile Verification" : "Verify OTP"}
            </CardTitle>
            <CardDescription>
              {step === "details"
                ? "Join Dose Mate to start managing medications safely"
                : step === "mobile"
                  ? "Enter your mobile number for verification"
                  : `We've sent a 6-digit code to +91 ${formData.mobileNumber}`}
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {step === "details" ? (
              <>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="firstName">First Name</Label>
                    <Input
                      id="firstName"
                      placeholder="John"
                      className="h-11"
                      value={formData.firstName}
                      onChange={(e) => setFormData({ ...formData, firstName: e.target.value })}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="lastName">Last Name</Label>
                    <Input
                      id="lastName"
                      placeholder="Doe"
                      className="h-11"
                      value={formData.lastName}
                      onChange={(e) => setFormData({ ...formData, lastName: e.target.value })}
                    />
                  </div>
                </div>
                <div className="space-y-2">
                  <Label htmlFor="role">Account Type</Label>
                  <Select value={formData.role} onValueChange={(value) => setFormData({ ...formData, role: value })}>
                    <SelectTrigger className="h-11">
                      <SelectValue placeholder="Select your role" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="patient">Patient</SelectItem>
                      <SelectItem value="caregiver">Caregiver/Family Member</SelectItem>
                      <SelectItem value="healthcare">Healthcare Provider</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <Button
                  className="w-full h-11 text-base"
                  onClick={handleDetailsNext}
                  disabled={!formData.firstName || !formData.lastName || !formData.role}
                >
                  Continue
                </Button>
              </>
            ) : step === "mobile" ? (
              <>
                <div className="space-y-2">
                  <Label htmlFor="mobile">Mobile Number</Label>
                  <div className="flex">
                    <div className="flex items-center px-3 border border-r-0 rounded-l-md bg-muted text-muted-foreground">
                      +91
                    </div>
                    <Input
                      id="mobile"
                      type="tel"
                      placeholder="Enter 10-digit mobile number"
                      className="h-11 rounded-l-none"
                      value={formData.mobileNumber}
                      onChange={(e) =>
                        setFormData({ ...formData, mobileNumber: e.target.value.replace(/\D/g, "").slice(0, 10) })
                      }
                      maxLength={10}
                    />
                  </div>
                </div>
                <div className="flex gap-2">
                  <Button variant="outline" className="flex-1 h-11 bg-transparent" onClick={() => setStep("details")}>
                    Back
                  </Button>
                  <Button
                    className="flex-1 h-11"
                    onClick={handleSendOTP}
                    disabled={!formData.mobileNumber || formData.mobileNumber.length !== 10 || isLoading}
                  >
                    {isLoading ? "Sending..." : "Send OTP"}
                  </Button>
                </div>
              </>
            ) : (
              <>
                <div className="space-y-2">
                  <Label htmlFor="otp">Enter OTP</Label>
                  <div className="flex justify-center">
                    <InputOTP maxLength={6} value={otp} onChange={(value) => setOtp(value)}>
                      <InputOTPGroup>
                        <InputOTPSlot index={0} />
                        <InputOTPSlot index={1} />
                        <InputOTPSlot index={2} />
                        <InputOTPSlot index={3} />
                        <InputOTPSlot index={4} />
                        <InputOTPSlot index={5} />
                      </InputOTPGroup>
                    </InputOTP>
                  </div>
                </div>
                <div className="flex items-center justify-between text-sm">
                  <button onClick={() => setStep("mobile")} className="text-primary hover:underline">
                    Change Number
                  </button>
                  <button onClick={handleResendOTP} className="text-primary hover:underline" disabled={isLoading}>
                    Resend OTP
                  </button>
                </div>
                <Button
                  className="w-full h-11 text-base"
                  onClick={handleVerifyOTP}
                  disabled={otp.length !== 6 || isLoading}
                >
                  {isLoading ? "Creating Account..." : "Verify & Create Account"}
                </Button>
              </>
            )}
            <div className="text-center text-sm text-muted-foreground">
              Already have an account?{" "}
              <Link href="/login" className="text-primary hover:underline">
                Sign in
              </Link>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
